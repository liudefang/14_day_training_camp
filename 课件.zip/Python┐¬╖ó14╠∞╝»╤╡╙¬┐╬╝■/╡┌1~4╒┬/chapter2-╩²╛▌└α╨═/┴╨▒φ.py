#_*_coding:utf-8_*_

#
# #方法一
# L1 = [] #定义空列表
#
# L2 = ['a','b','c','d'] #存4个值，索引为0-3
#
# L3 = ['abc',['def','ghi']]  #嵌套列表
#
#
# #方法二
#
# L4 = list()
# print(L4)


L2 = ['a', 'b', 'c', 'L', 'I', 'e', 1, 2]



for i in L2:
    print(i)

