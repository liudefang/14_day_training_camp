

s = "路飞学城"
print(s)