#_*_coding:utf-8_*_


count = 0

while True:
    print("forever 21 ",count)
    count += 1
