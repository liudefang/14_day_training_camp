#_*_coding:utf-8_*_


f = open("兼职白领学生空姐模特护士联系方式.txt",'r',encoding="gbk")

for line in f:
    print(line)

f.close()

