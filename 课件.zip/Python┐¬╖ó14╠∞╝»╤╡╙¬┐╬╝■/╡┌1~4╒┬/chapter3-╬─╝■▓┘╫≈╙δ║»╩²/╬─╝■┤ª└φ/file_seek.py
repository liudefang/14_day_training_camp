#_*_coding:utf-8_*_


f = open("兼职白领学生空姐模特护士联系方式utf8.txt",'r+',encoding="utf-8")

f.seek(6)

f.write("[路飞学城]")

f.close()