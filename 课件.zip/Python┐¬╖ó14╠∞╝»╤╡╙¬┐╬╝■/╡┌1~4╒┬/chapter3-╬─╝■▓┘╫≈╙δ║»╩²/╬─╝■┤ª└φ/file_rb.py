


f = open("兼职白领学生空姐模特护士联系方式.txt",'rb')
print(f.read().decode("gbk"))