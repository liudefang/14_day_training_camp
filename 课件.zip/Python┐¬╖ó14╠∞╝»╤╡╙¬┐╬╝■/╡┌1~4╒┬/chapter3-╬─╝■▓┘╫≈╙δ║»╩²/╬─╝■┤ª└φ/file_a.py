import chardet
chardet.detect()

f = open("兼职白领学生空姐模特护士联系方式.txt",'a',encoding="gbk")

f.write("\n杜姗姗 北京  167 49 13324523342")
f.close()
