#_*_coding:utf-8_*_

msg = "又回到最初的起点"
f = open("print_tofile","w")
print(msg,"记忆中你青涩的脸",sep="|",end="",file=f)
print(msg,"记忆中你青涩的脸",sep="|",end="",file=f)