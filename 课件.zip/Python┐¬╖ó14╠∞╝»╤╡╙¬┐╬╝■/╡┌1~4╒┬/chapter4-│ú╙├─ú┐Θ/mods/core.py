#_*_coding:utf-8_*_



print("run in cores....")


def sayhi():
    print('sayhi...')