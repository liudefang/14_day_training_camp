


DATABASES= {
    'host':'localhost'
}

print('in proj/settings.py')