#!/usr/bin/env python




from my_proj.crm import views


views.sayhi()