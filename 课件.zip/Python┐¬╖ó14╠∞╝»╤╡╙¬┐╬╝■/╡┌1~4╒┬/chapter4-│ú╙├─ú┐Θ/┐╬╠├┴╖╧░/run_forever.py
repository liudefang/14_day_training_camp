
import time

count = 0 
while True:
  count += 1 
  print('loop ',count)
  time.sleep(1)


