#_*_coding:utf-8_*_


import json

# data = {
#
#     'roles':[
#         {'role':'monster','type':'pig','life':50},
#         {'role':'hero','type':'关羽','life':80},
#     ]
# }
#





# d = json.dumps(data)  #仅转成字符串

# d2 = json.loads(d)
# print(d2['roles'])
# # print(d,type(d))
# f = open("test.json","w")
# json.dump(data,f) #转成字符并写入文件



#
# f = open("test.json","r")
#
# data = json.load(f)
#
# print(data['roles'])