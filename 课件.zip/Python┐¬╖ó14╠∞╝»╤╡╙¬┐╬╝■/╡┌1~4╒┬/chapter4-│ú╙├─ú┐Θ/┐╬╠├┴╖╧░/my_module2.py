#_*_coding:utf-8_*_



def sayhi(name):
    print("hello", name)

def saybye(name):
    print("bye",name)



#sayhi('Alex')