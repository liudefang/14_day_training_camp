
from . import models
from ..proj import settings

def sayhi():
    print('hello world!')


